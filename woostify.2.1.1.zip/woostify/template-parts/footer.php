<?php
/**
 * Footer template
 *
 * @package woostify
 */

do_action( 'woostify_template_part_footer' );
